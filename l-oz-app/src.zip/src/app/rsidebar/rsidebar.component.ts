import { Component } from '@angular/core';

@Component({
  selector: 'app-rsidebar',
  templateUrl: './rsidebar.component.html',
  styleUrls: ['./rsidebar.component.scss'],
})
export class RsidebarComponent {}
