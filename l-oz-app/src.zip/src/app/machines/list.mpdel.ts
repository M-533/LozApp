export class BigList{

constructor(public id:number , public mName:string, public lastW:Date , public lastF:Date ,public showDetailes:boolean     ){}

}
