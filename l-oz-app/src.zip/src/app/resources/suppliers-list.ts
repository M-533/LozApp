export class suppliersRow {
  constructor(
    public materialName: any,
    public category: any,
    public itemCode: any,
    public supplierCode: any,
    public date: Date
  ) {}
}
